/*==================================================
 *  Exhibit.Coders English localization
 *==================================================
 */

if (!("l10n" in Exhibit.Coders)) {
    Exhibit.Coders.l10n = {};
}

Exhibit.Coders.l10n.mixedCaseLabel = "mixed";
Exhibit.Coders.l10n.missingCaseLabel = "missing";
Exhibit.Coders.l10n.othersCaseLabel = "others";
