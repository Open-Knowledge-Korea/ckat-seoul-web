/*==================================================
 *  Exhibit.TileView Chinese localization
 *==================================================
 */

if (!("l10n" in Exhibit.TileView)) {
    Exhibit.TileView.l10n = {};
}

Exhibit.TileView.l10n.viewLabel = "Tiles";
Exhibit.TileView.l10n.viewTooltip = "View items as tiles in a list";
